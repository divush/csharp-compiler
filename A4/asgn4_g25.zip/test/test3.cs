namespace Program {
    class Program {
        int Main() {
            int num;
            for(int i = 0;i<10;i = i + 1) {
                num = num + 1;
                for (int j = 10; j > 1; j = j -1) {
                    int k = 0;
                    k = k + 1;
                }
                while(num < 100){
                    num = num * 10;
                    while( i > 2) {
                        i = i - 1;
                        k = 10;
                    }
                }
            }
        }
    }
}